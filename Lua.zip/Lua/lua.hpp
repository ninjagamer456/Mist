
extern "C"
{
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
}